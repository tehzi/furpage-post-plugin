/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	// The require scope
/******/ 	var __webpack_require__ = {};
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "handler": () => (/* binding */ handler)
});

;// CONCATENATED MODULE: external "reflect-metadata"
const external_reflect_metadata_namespaceObject = require("reflect-metadata");
;// CONCATENATED MODULE: external "@nestjs/core"
const core_namespaceObject = require("@nestjs/core");
;// CONCATENATED MODULE: external "@nestjs/platform-express"
const platform_express_namespaceObject = require("@nestjs/platform-express");
;// CONCATENATED MODULE: external "express"
const external_express_namespaceObject = require("express");
var external_express_default = /*#__PURE__*/__webpack_require__.n(external_express_namespaceObject);
;// CONCATENATED MODULE: external "aws-serverless-express"
const external_aws_serverless_express_namespaceObject = require("aws-serverless-express");
;// CONCATENATED MODULE: external "@nestjs/common"
const common_namespaceObject = require("@nestjs/common");
;// CONCATENATED MODULE: external "@nestjs/graphql"
const graphql_namespaceObject = require("@nestjs/graphql");
;// CONCATENATED MODULE: ./src/app.service.ts
var _dec, _dec2, _dec3, _dec4, _class, _class2;

function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }


let AppService = (_dec = (0,graphql_namespaceObject.Resolver)(), _dec2 = (0,graphql_namespaceObject.Query)(() => String), _dec3 = Reflect.metadata("design:type", Function), _dec4 = Reflect.metadata("design:paramtypes", []), _dec(_class = (_class2 = class AppService {
  getHello() {
    return "Hello World 123!";
  }

}, (_applyDecoratedDescriptor(_class2.prototype, "getHello", [_dec2, _dec3, _dec4], Object.getOwnPropertyDescriptor(_class2.prototype, "getHello"), _class2.prototype)), _class2)) || _class);
;// CONCATENATED MODULE: ./src/app.controller.ts
var app_controller_dec, app_controller_dec2, app_controller_dec3, app_controller_class;



let AppController = (app_controller_dec = (0,common_namespaceObject.Controller)(), app_controller_dec2 = Reflect.metadata("design:type", Function), app_controller_dec3 = Reflect.metadata("design:paramtypes", [typeof AppService === "undefined" ? Object : AppService]), app_controller_dec(app_controller_class = app_controller_dec2(app_controller_class = app_controller_dec3(app_controller_class = class AppController {
  constructor(appService) {
    this.appService = appService;
  }

}) || app_controller_class) || app_controller_class) || app_controller_class);
;// CONCATENATED MODULE: external "@nestjs/apollo"
const apollo_namespaceObject = require("@nestjs/apollo");
;// CONCATENATED MODULE: external "@nestjs/config"
const config_namespaceObject = require("@nestjs/config");
;// CONCATENATED MODULE: external "ydb-sdk"
const external_ydb_sdk_namespaceObject = require("ydb-sdk");
;// CONCATENATED MODULE: ./src/ydb/ydb.constant.ts
const CONNECTION_NAME = "defaultConnection";
const DB_TIMEOUT = 10_000;
;// CONCATENATED MODULE: ./src/ydb/metadata/entity-metadata.ts
class EntityMetadata {
  constructor(options) {
    this.connection = void 0;

    if (!options.connection) {
      throw new Error("No connection");
    }

    this.connection = options.connection;
  }

  registerColumn() {}

}
;// CONCATENATED MODULE: ./src/ydb/metadata/ydb-metadata-store.ts
function _classPrivateFieldLooseBase(receiver, privateKey) { if (!Object.prototype.hasOwnProperty.call(receiver, privateKey)) { throw new TypeError("attempted to use private field on non-instance"); } return receiver; }

var id = 0;

function _classPrivateFieldLooseKey(name) { return "__private_" + id++ + "_" + name; }

var _tables = /*#__PURE__*/_classPrivateFieldLooseKey("tables");

var _columns = /*#__PURE__*/_classPrivateFieldLooseKey("columns");

class YdbMetadataStore {
  static addTable(table) {
    _classPrivateFieldLooseBase(this, _tables)[_tables].push(table);
  }

  static getTables() {
    return _classPrivateFieldLooseBase(this, _tables)[_tables];
  }

  static addColumn(column) {
    _classPrivateFieldLooseBase(this, _columns)[_columns].push(column);
  }

  static getColumns() {
    return _classPrivateFieldLooseBase(this, _columns)[_columns];
  }

}
Object.defineProperty(YdbMetadataStore, _tables, {
  writable: true,
  value: []
});
Object.defineProperty(YdbMetadataStore, _columns, {
  writable: true,
  value: []
});
;// CONCATENATED MODULE: ./src/ydb/metadata/ydb-metadata.provider.ts
var ydb_metadata_provider_dec, ydb_metadata_provider_dec2, ydb_metadata_provider_dec3, ydb_metadata_provider_dec4, ydb_metadata_provider_class, ydb_metadata_provider_columns;

var ydb_metadata_provider_id = 0;

function ydb_metadata_provider_classPrivateFieldLooseKey(name) { return "__private_" + ydb_metadata_provider_id++ + "_" + name; }






let YdbMetadata = (ydb_metadata_provider_dec = (0,common_namespaceObject.Injectable)(), ydb_metadata_provider_dec2 = function (target, key) {
  return (0,common_namespaceObject.Inject)(CONNECTION_NAME)(target, undefined, 0);
}, ydb_metadata_provider_dec3 = Reflect.metadata("design:type", Function), ydb_metadata_provider_dec4 = Reflect.metadata("design:paramtypes", [typeof external_ydb_sdk_namespaceObject.Driver === "undefined" ? Object : external_ydb_sdk_namespaceObject.Driver]), ydb_metadata_provider_dec(ydb_metadata_provider_class = ydb_metadata_provider_dec2(ydb_metadata_provider_class = ydb_metadata_provider_dec3(ydb_metadata_provider_class = ydb_metadata_provider_dec4(ydb_metadata_provider_class = (ydb_metadata_provider_columns = /*#__PURE__*/ydb_metadata_provider_classPrivateFieldLooseKey("columns"), class YdbMetadata {
  constructor(connection) {
    this.connection = connection;
    Object.defineProperty(this, ydb_metadata_provider_columns, {
      writable: true,
      value: []
    });
    this.build();
  }

  build() {
    const tables = YdbMetadataStore.getTables();
    const entityMetadatas = tables.map(table => this.createEntityMetadata(table));
  }

  createEntityMetadata(table) {
    return new EntityMetadata({
      connection: this.connection,
      table
    });
  }

})) || ydb_metadata_provider_class) || ydb_metadata_provider_class) || ydb_metadata_provider_class) || ydb_metadata_provider_class);
;// CONCATENATED MODULE: external "cli-highlight"
const external_cli_highlight_namespaceObject = require("cli-highlight");
;// CONCATENATED MODULE: external "debug"
const external_debug_namespaceObject = require("debug");
var external_debug_default = /*#__PURE__*/__webpack_require__.n(external_debug_namespaceObject);
;// CONCATENATED MODULE: ./src/ydb/logger/logger.provider.ts
var logger_provider_dec, logger_provider_dec2, logger_provider_dec3, logger_provider_class;




let Logger = (logger_provider_dec = (0,common_namespaceObject.Injectable)(), logger_provider_dec2 = Reflect.metadata("design:type", Function), logger_provider_dec3 = Reflect.metadata("design:paramtypes", [void 0]), logger_provider_dec(logger_provider_class = logger_provider_dec2(logger_provider_class = logger_provider_dec3(logger_provider_class = class Logger {
  constructor(enabled) {
    this.enabled = enabled;
    this.debugQuery = external_debug_default()("ydb:query:log");
    this.debugSchema = external_debug_default()("ydb:schema:log");
    this.debugLog = external_debug_default()("ydb:log");
    this.debugInfo = external_debug_default()("ydb:info");
    this.debugWarn = external_debug_default()("ydb:warn");

    if (this.enabled) {
      external_debug_default().enable("ydb:*");
    }
  }

  highlight(sql) {
    return (0,external_cli_highlight_namespaceObject.highlight)(sql, {
      language: "sql",
      ignoreIllegals: true
    });
  }

  logQuery(query, parameters) {
    if (this.debugQuery.enabled) {
      this.debugQuery(this.highlight(query));

      if (parameters?.length) {
        this.debugQuery("parameters:", parameters);
      }
    }
  }

  logSchema(message) {
    if (this.debugSchema.enabled) {
      this.debugSchema(message);
    }
  }

  log(message, level = "log") {
    switch (level) {
      case "log":
        if (this.debugLog.enabled) {
          this.debugLog(message);
        }

        break;

      case "info":
        if (this.debugInfo.enabled) {
          this.debugInfo(message);
        }

        break;

      case "warn":
        if (this.debugWarn.enabled) {
          this.debugWarn(message);
        }

        break;
    }
  }

}) || logger_provider_class) || logger_provider_class) || logger_provider_class);
;// CONCATENATED MODULE: ./src/ydb/struct/table.struct.ts
class Table {
  constructor(options = {}) {
    this.options = options;
    this.columns = void 0;
    this.indices = void 0;
  }

  get name() {
    return this.options.name;
  }

  static create() {}

}
;// CONCATENATED MODULE: ./src/ydb/query-runner/query-runner.provider.ts
var query_runner_provider_dec, query_runner_provider_dec2, query_runner_provider_dec3, query_runner_provider_dec4, query_runner_provider_class, _loadedTables;

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ownKeys(Object(source), !0).forEach(function (key) { _defineProperty(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function query_runner_provider_classPrivateFieldLooseBase(receiver, privateKey) { if (!Object.prototype.hasOwnProperty.call(receiver, privateKey)) { throw new TypeError("attempted to use private field on non-instance"); } return receiver; }

var query_runner_provider_id = 0;

function query_runner_provider_classPrivateFieldLooseKey(name) { return "__private_" + query_runner_provider_id++ + "_" + name; }






let QueryRunner = (query_runner_provider_dec = (0,common_namespaceObject.Injectable)(), query_runner_provider_dec2 = function (target, key) {
  return (0,common_namespaceObject.Inject)(CONNECTION_NAME)(target, undefined, 0);
}, query_runner_provider_dec3 = Reflect.metadata("design:type", Function), query_runner_provider_dec4 = Reflect.metadata("design:paramtypes", [typeof external_ydb_sdk_namespaceObject.Driver === "undefined" ? Object : external_ydb_sdk_namespaceObject.Driver, typeof Logger === "undefined" ? Object : Logger]), query_runner_provider_dec(query_runner_provider_class = query_runner_provider_dec2(query_runner_provider_class = query_runner_provider_dec3(query_runner_provider_class = query_runner_provider_dec4(query_runner_provider_class = (_loadedTables = /*#__PURE__*/query_runner_provider_classPrivateFieldLooseKey("loadedTables"), class QueryRunner {
  constructor(driver, logger) {
    this.driver = driver;
    this.logger = logger;
    Object.defineProperty(this, _loadedTables, {
      writable: true,
      value: []
    });
  }

  async getTable(tableName) {
    query_runner_provider_classPrivateFieldLooseBase(this, _loadedTables)[_loadedTables] = await this.loadTables([tableName]);
    return query_runner_provider_classPrivateFieldLooseBase(this, _loadedTables)[_loadedTables][0] ?? null;
  }

  async getTables(tableNames) {
    query_runner_provider_classPrivateFieldLooseBase(this, _loadedTables)[_loadedTables] = await this.loadTables(tableNames);
    return query_runner_provider_classPrivateFieldLooseBase(this, _loadedTables)[_loadedTables];
  }

  async loadTables(tableNames) {
    if (tableNames?.length === 0) {
      return [];
    }

    const directoryListing = await this.driver.schemeClient.listDirectory("");
    let tablesEntry = directoryListing.children.filter(entity => entity.type === external_ydb_sdk_namespaceObject.Ydb.Scheme.Entry.Type.TABLE);
    const {
      self: {
        name: databaseName
      }
    } = directoryListing;
    this.logger.logSchema(`Start scanning for database: ${databaseName}`);

    if (tableNames) {
      tablesEntry = tablesEntry.filter(({
        name
      }) => tableNames.includes(name));
    }

    this.logger.logSchema(`Found tables: ${tablesEntry.map(({
      name
    }) => name).join(", ")}`);

    if (tablesEntry.length === 0) {
      return [];
    }

    const session = await this.driver.tableClient.withSession(async sessionState => sessionState);
    return Promise.all(tablesEntry.map(async options => {
      const {
        name
      } = options;
      const table = new Table(_objectSpread({}, options));
      const {
        columns,
        indexes
      } = await session.describeTable(name);
      return table;
    }));
  }

})) || query_runner_provider_class) || query_runner_provider_class) || query_runner_provider_class) || query_runner_provider_class);
;// CONCATENATED MODULE: ./src/ydb/builder/ydb-builder.provider.ts
var ydb_builder_provider_dec, ydb_builder_provider_dec2, ydb_builder_provider_dec3, ydb_builder_provider_class;




let YDbBuilder = (ydb_builder_provider_dec = (0,common_namespaceObject.Injectable)(), ydb_builder_provider_dec2 = Reflect.metadata("design:type", Function), ydb_builder_provider_dec3 = Reflect.metadata("design:paramtypes", [typeof YdbMetadata === "undefined" ? Object : YdbMetadata, typeof QueryRunner === "undefined" ? Object : QueryRunner]), ydb_builder_provider_dec(ydb_builder_provider_class = ydb_builder_provider_dec2(ydb_builder_provider_class = ydb_builder_provider_dec3(ydb_builder_provider_class = class YDbBuilder {
  constructor(metadata, queryRunner) {
    this.metadata = metadata;
    this.queryRunner = queryRunner;
    this.synchronize();
  }

  async synchronize() {
    await this.renameColumns();
    await this.createNewTables();
    await this.dropRemovedColumns();
    await this.addNewColumns();
    await this.updatePrimaryKeys();
    await this.updateExistColumns();
    await this.createNewIndices();
    await this.createNewChecks();
  }

  async renameColumns() {}

  async createNewTables() {
    const tables = await this.queryRunner.getTables(); // this.driver.tableClient.withSession(async (session) => {
    //     debugger;
    //     console.log(await this.driver.schemeClient.listDirectory(""))
    //     // await session.createTable(
    //     //     "foo",
    //     //     new TableDescription()
    //     //         .withColumn(new Column("customer_id", Types.optional(Types.UINT64)))
    //     //         .withColumn(new Column("order_id", Types.optional(Types.UINT64)))
    //     //         .withColumn(new Column("description", Types.optional(Types.UTF8)))
    //     //         .withColumn(new Column("order_date", Types.optional(Types.DATE)))
    //     //         .withPrimaryKeys("customer_id", "order_id"),
    //     // );
    //     // console.log(await session.executeQuery(query))
    //     debugger;
    // });
  }

  async dropRemovedColumns() {}

  async addNewColumns() {}

  async updatePrimaryKeys() {}

  async updateExistColumns() {}

  async createNewIndices() {}

  async createNewChecks() {}

}) || ydb_builder_provider_class) || ydb_builder_provider_class) || ydb_builder_provider_class);
;// CONCATENATED MODULE: ./src/ydb/ydb.module.ts
var ydb_module_dec, ydb_module_dec2, ydb_module_class;








let YdbModule = (ydb_module_dec = (0,common_namespaceObject.Global)(), ydb_module_dec2 = (0,common_namespaceObject.Module)({}), ydb_module_dec(ydb_module_class = ydb_module_dec2(ydb_module_class = class YdbModule {
  static forRoot(options) {
    const providers = [];
    const exports = [];
    const connectionProvider = {
      provide: CONNECTION_NAME,
      useFactory: async () => {
        const connection = await this.createConnection(options);
        return connection;
      }
    };
    const loggerFactory = {
      provide: Logger,
      useFactory: () => {
        const logger = new Logger(options.logger);
        return logger;
      }
    };
    providers.push(connectionProvider, loggerFactory, QueryRunner, YdbMetadata, YDbBuilder);
    exports.push(connectionProvider, loggerFactory, QueryRunner, YdbMetadata, YDbBuilder);
    return {
      module: YdbModule,
      providers,
      exports
    };
  }

  static forFeature(options) {
    // debugger
    return {
      module: YdbModule
    };
  }

  static async createConnection(options) {
    const {
      database,
      endpoint
    } = options;
    const driver = new external_ydb_sdk_namespaceObject.Driver({
      database,
      endpoint,
      authService: new external_ydb_sdk_namespaceObject.AnonymousAuthService()
    });

    if (!(await driver.ready(DB_TIMEOUT))) {
      console.error(`Driver has not become ready in ${DB_TIMEOUT}ms!`);
      throw new Error(`Driver has not become ready in ${DB_TIMEOUT}ms!`);
    } // await driver.tableClient.withSession(async (session) => {
    //     console.info(session);
    //     debugger
    //     // await createTable(session, logger);
    //     // await fillTableWithData(session, logger);
    // });
    // debugger


    return driver;
  }

}) || ydb_module_class) || ydb_module_class);
;// CONCATENATED MODULE: ./src/ydb/helpers/YdbTypesStatic.ts
// eslint-disable-next-line unicorn/no-static-only-class
class YdbTypesStatic {}
YdbTypesStatic.Bool = "Bool";
YdbTypesStatic.Int8 = "Int8";
YdbTypesStatic.Int16 = "Int16";
YdbTypesStatic.Int32 = "Int32";
YdbTypesStatic.Int64 = "Int64";
YdbTypesStatic.Uint8 = "Uint8";
YdbTypesStatic.Uint16 = "Uint16";
YdbTypesStatic.Uint32 = "Uint32";
YdbTypesStatic.Uint64 = "Uint64";
YdbTypesStatic.Float = "Float";
YdbTypesStatic.Double = "Double";
YdbTypesStatic.Decimal = "Decimal";
YdbTypesStatic.DyNumber = "DyNumber";
YdbTypesStatic.String = "String";
YdbTypesStatic.Utf8 = "Utf8";
YdbTypesStatic.Json = "Json";
YdbTypesStatic.JsonDocument = "JsonDocument";
YdbTypesStatic.Yson = "Yson";
YdbTypesStatic.Uuid = "Uuid";
YdbTypesStatic.Date = "Date";
YdbTypesStatic.Datetime = "Datetime";
YdbTypesStatic.Timestamp = "Timestamp";
YdbTypesStatic.Interval = "Interval";
YdbTypesStatic.TzDate = "TzDate";
YdbTypesStatic.TzDateTime = "TzDateTime";
YdbTypesStatic.TzTimestamp = "TzTimestamp";
;// CONCATENATED MODULE: ./src/ydb/utils/is-object.util.ts
function isObject(value) {
  return value !== null && value?.toString() === "[object Object]";
}
;// CONCATENATED MODULE: ./src/ydb/decorators/Column.ts



function Column(typeOrOption, maybeOption) {
  let type;
  let options;
  type = typeof typeOrOption === "string" ? typeOrOption : null;
  options = isObject(typeOrOption) ? typeOrOption : maybeOption;
  options = options ?? {};
  return (target, key) => {
    if (!type) {
      ({
        type = null
      } = options);
    }

    if (type === null) {
      const reflectKeyType = Reflect?.getMetadata("design:type", target, key);
      type = [reflectKeyType === String && YdbTypesStatic.Utf8].find(Boolean);
    }

    YdbMetadataStore.addColumn({
      target: target.constructor,
      type,
      key,
      options
    });
  };
}
;// CONCATENATED MODULE: ./src/ydb/decorators/Entity.ts
function Entity_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }

function Entity_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? Entity_ownKeys(Object(source), !0).forEach(function (key) { Entity_defineProperty(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : Entity_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }

function Entity_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }



function Entity(nameOrOptions, maybeOption) {
  const options = (isObject(nameOrOptions) ? nameOrOptions : maybeOption) || {};
  const name = typeof nameOrOptions === "string" ? nameOrOptions : nameOrOptions?.name;
  return target => {
    YdbMetadataStore.addTable(Entity_objectSpread({
      target,
      name
    }, options));
  };
}
;// CONCATENATED MODULE: ./src/images/images.entity.ts
var images_entity_dec, images_entity_dec2, images_entity_dec3, images_entity_class, images_entity_class2, _descriptor;

function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

function images_entity_applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'proposal-class-properties is enabled and runs after the decorators transform.'); }



let ImagesEntity = (images_entity_dec = Entity(), images_entity_dec2 = Column({}), images_entity_dec3 = Reflect.metadata("design:type", String), images_entity_dec(images_entity_class = (images_entity_class2 = class ImagesEntity {
  constructor() {
    _initializerDefineProperty(this, "url", _descriptor, this);
  } // tags!: string;
  // fileUrl!: string;
  // base64Image!: string;
  // title!: string;
  // queueId!: string;
  // queue: QueueEntity;
  // created!: Date;
  // updated!: Date;


}, (_descriptor = images_entity_applyDecoratedDescriptor(images_entity_class2.prototype, "url", [images_entity_dec2, images_entity_dec3], {
  configurable: true,
  enumerable: true,
  writable: true,
  initializer: null
})), images_entity_class2)) || images_entity_class);
;// CONCATENATED MODULE: ./src/images/images.module.ts
var images_module_dec, images_module_class;




let ImagesModule = (images_module_dec = (0,common_namespaceObject.Module)({
  imports: [YdbModule.forFeature([ImagesEntity]) // NestjsQueryGraphQLModule.forFeature({
  //     imports: [YdbModule.forFeature([ImagesEntity])],
  //     resolvers: [{ DTOClass: ImagesDto, EntityClass: ImagesEntity }],
  // }),
  ]
}), images_module_dec(images_module_class = class ImagesModule {}) || images_module_class);
;// CONCATENATED MODULE: ./src/app.module.ts
var app_module_dec, app_module_class;









let AppModule = (app_module_dec = (0,common_namespaceObject.Module)({
  imports: [config_namespaceObject.ConfigModule.forRoot(), graphql_namespaceObject.GraphQLModule.forRoot({
    // TODO исправить для прода и теста
    path: "/proxy/graphql",
    driver: apollo_namespaceObject.ApolloDriver,
    autoSchemaFile: true
  }), YdbModule.forRoot({
    endpoint: process.env.YDB_ENDPOINT,
    database: process.env.DATABASE,
    logger: true
  }), ImagesModule],
  controllers: [AppController],
  providers: [AppService]
}), app_module_dec(app_module_class = class AppModule {}) || app_module_class);
;// CONCATENATED MODULE: external "aws-serverless-express/middleware"
const middleware_namespaceObject = require("aws-serverless-express/middleware");
;// CONCATENATED MODULE: ./graphql.ts







let server;

async function bootstrap() {
  if (!server) {
    const app = external_express_default()();
    const nest = await core_namespaceObject.NestFactory.create(AppModule, new platform_express_namespaceObject.ExpressAdapter(app));
    nest.use((0,middleware_namespaceObject.eventContext)());
    await nest.init();
    server = (0,external_aws_serverless_express_namespaceObject.createServer)(app, undefined, []);
  }

  return server;
}

const handler = async (event, context) => {
  server = await bootstrap();
  return (0,external_aws_serverless_express_namespaceObject.proxy)(server, event, context, "PROMISE").promise; // return {
  //     statusCode: 200,
  //     body: "hello world!",
  // };
};
var __webpack_export_target__ = exports;
for(var i in __webpack_exports__) __webpack_export_target__[i] = __webpack_exports__[i];
if(__webpack_exports__.__esModule) Object.defineProperty(__webpack_export_target__, "__esModule", { value: true });
/******/ })()
;
//# sourceMappingURL=graphql.js.map